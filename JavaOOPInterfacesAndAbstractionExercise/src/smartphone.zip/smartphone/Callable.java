package smartphone;

public interface Callable {

    String call();
}
