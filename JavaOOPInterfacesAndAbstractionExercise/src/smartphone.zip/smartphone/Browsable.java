package smartphone;

public interface Browsable {
    String browse();
}
