package wildFarm;

import java.text.DecimalFormat;

public class Felime  extends Mammal{
    public Felime(String animalName, String animalType, Double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }

    @Override
    void makeSound() {

    }

    @Override
    void eat(Food food) {
        Integer quantity = food.getQuantity()+super.getFoodEaten();
        this.setFoodEaten(quantity);
    }
    @Override
    public String toString() {
        DecimalFormat decimalFormat = new DecimalFormat("###.##");
        return String.format("%s[%s, %s, %s, %d]",super.getAnimalName(),super.getAnimalType(),decimalFormat.format(super.getAnimalWeight())
                ,super.getLivingRegion(),super.getFoodEaten());
    }
}
